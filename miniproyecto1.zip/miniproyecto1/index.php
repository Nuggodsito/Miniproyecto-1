<?php
// Configurar ruta base
$base_url = '/MINIPROYECTO1';

// Incluir utilities y header
include_once 'includes/utilities.php';
include_once 'includes/header.php';
?>

<div class="container">
    <div class="menu-header">
        <h1>Proyecto #1 - PHP</h1>
        <p>Estructuras de Control, Funciones y Clases</p>
        <div class="students">
            <span>Luis Calderón</span>
            <span>Luis Ortega</span>
        </div>
    </div>

    <div class="problems-grid">
        <?php
        $problemas = [
            "Calculadora de Datos Estadísticos",
            "Suma del 1 al 1000",
            "Múltiplos de 4", 
            "Pares e Impares 1-200",
            "Clasificación de Edades",
            "Presupuesto Hospital",
            "Calculadora de Notas",
            "Estación del Año",
            "Potencia de Números",
            "Vendedores y Productos"
        ];
        
        foreach ($problemas as $indice => $titulo) {
            $numero = $indice + 1;
            echo "
            <div class='problem-card'>
                <h3>Problema #$numero</h3>
                <p>$titulo</p>
                <a href='problemas/problema$numero.php' class='btn'>Resolver</a>
            </div>";
        }
        ?>
    </div>
</div>


<?php
include_once 'footer.php';
?>