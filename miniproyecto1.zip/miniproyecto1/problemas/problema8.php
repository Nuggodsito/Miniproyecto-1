<?php
$base_url = '/MINIPROYECTO1';
include_once '../includes/utilities.php';
include_once '../includes/header.php';

$estaciones = [
    'Verano' => ['inicio' => '12-21', 'fin' => '03-20', 'imagen' => 'verano.jpg'],
    'Otoño' => ['inicio' => '03-21', 'fin' => '06-21', 'imagen' => 'otono.jpg'],
    'Invierno' => ['inicio' => '06-22', 'fin' => '09-22', 'imagen' => 'invierno.jpg'],
    'Primavera' => ['inicio' => '09-23', 'fin' => '12-20', 'imagen' => 'primavera.jpg']
];

function estaEnRango($fecha, $inicio, $fin) {
    return ($inicio > $fin) ? ($fecha >= $inicio || $fecha <= $fin) : ($fecha >= $inicio && $fecha <= $fin);
}

function formatFecha($fecha) {
    $meses = ['01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr', '05' => 'May', '06' => 'Jun',
              '07' => 'Jul', '08' => 'Ago', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic'];
    list($mes, $dia) = explode('-', $fecha);
    return $dia . ' de ' . $meses[$mes];
}

$resultado = [];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha_input = Utilities::sanitizarTexto($_POST['fecha'] ?? '');
    
    if (Utilities::validarFecha($fecha_input)) {
        list($mes, $dia, $año) = explode('/', $fecha_input);
        $fecha_actual = sprintf('%02d-%02d', (int)$mes, (int)$dia);
        
        foreach ($estaciones as $estacion => $rango) {
            if (estaEnRango($fecha_actual, $rango['inicio'], $rango['fin'])) {
                $resultado = [
                    'fecha' => $fecha_input,
                    'estacion' => $estacion,
                    'rango' => $rango,
                    'imagen' => $rango['imagen']
                ];
                break;
            }
        }
        
        if (!$resultado) {
            $error = "No se pudo determinar la estacion para la fecha ingresada.";
        }
    } else {
        $error = "Por favor ingrese una fecha valida en formato MM/DD/YYYY.";
    }
}
?>

<div class="container">
    <div class="problem-header">
        <h1>Problema #8: Estacion del Año</h1>
        <p>Determinar la estacion del año segun la fecha ingresada</p>
        <?php echo Utilities::generarEnlace('../index.php'); ?>
    </div>

    <div class="form-container">
        <form method="POST" action="">
            <div class="form-group">
                <label for="fecha">Ingrese una fecha (MM/DD/YYYY):</label>
                <input type="text" id="fecha" name="fecha" required 
                       placeholder="Ej: 09/25/2024"
                       pattern="(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/([0-9]{4})"
                       title="Formato: MM/DD/YYYY">
                <small>Formato: MM/DD/YYYY (Ej: 09/25/2024)</small>
            </div>
            
            <button type="submit" class="btn">Determinar Estacion</button>
        </form>
    </div>

    <?php if ($error): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if (!empty($resultado)): ?>
        <div class="resultados">
            <div class="season-result">
                <div class="season-card <?php echo strtolower($resultado['estacion']); ?>" 
                     style="background-image: url('../imagenes/<?php echo $resultado['imagen']; ?>');">
                    <div class="season-info-overlay">
                        <h3><?php echo $resultado['estacion']; ?></h3>
                        <p class="season-date">Fecha ingresada: <?php echo $resultado['fecha']; ?></p>
                        <p class="season-range">
                            La estación es: <strong><?php echo $resultado['estacion']; ?></strong>
                        </p>
                        <p class="season-period">
                            Del <?php echo formatFecha($resultado['rango']['inicio']); ?> 
                            al <?php echo formatFecha($resultado['rango']['fin']); ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="seasons-info">
                <h4>Calendario de Estaciones</h4>
                <div class="seasons-grid">
                    <?php foreach ($estaciones as $estacion => $datos): ?>
                        <div class="season-info-card <?php echo strtolower($estacion); echo ($estacion === $resultado['estacion']) ? ' current' : ''; ?>"
                             style="background-image: url('../imagenes/<?php echo $datos['imagen']; ?>');">
                            <div class="season-mini-overlay">
                                <h5><?php echo $estacion; ?></h5>
                                <p class="season-dates">
                                    <?php echo formatFecha($datos['inicio']); ?> -<br>
                                    <?php echo formatFecha($datos['fin']); ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('fecha').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) value = value.substring(0, 2) + '/' + value.substring(2);
    if (value.length >= 5) value = value.substring(0, 5) + '/' + value.substring(5, 9);
    e.target.value = value;
});
</script>

<style>
.season-result { text-align: center; margin: 30px 0; }

/* Tarjeta principal con imagen de fondo */
.season-card { 
    background: var(--blanco); 
    padding: 0;
    border-radius: 15px; 
    box-shadow: 0 10px 25px rgba(139, 95, 191, 0.3); 
    border: 4px solid transparent; 
    max-width: 600px; 
    margin: 0 auto;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    min-height: 400px;
    overflow: hidden;
}

/* Overlay para la información */
.season-info-overlay {
    position: absolute;
    top: 20px;
    left: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    border-left: 5px solid;
}

.season-card.verano { border-color: #E53E3E; }
.season-card.verano .season-info-overlay { border-left-color: #E53E3E; }

.season-card.otoño { border-color: #D69E2E; }
.season-card.otoño .season-info-overlay { border-left-color: #D69E2E; }

.season-card.invierno { border-color: #6CB2EB; }
.season-card.invierno .season-info-overlay { border-left-color: #6CB2EB; }

.season-card.primavera { border-color: #68D391; }
.season-card.primavera .season-info-overlay { border-left-color: #68D391; }

.season-info-overlay h3 { 
    color: var(--texto-oscuro); 
    margin-bottom: 15px; 
    font-size: 2em;
    border-bottom: 2px solid currentColor;
    padding-bottom: 8px;
}

.season-date { 
    color: var(--texto-oscuro); 
    margin: 8px 0; 
    font-size: 1.1em;
}

.season-range { 
    color: var(--morado-principal); 
    font-weight: bold; 
    margin: 12px 0;
    font-size: 1.3em;
    background: rgba(139, 95, 191, 0.1);
    padding: 8px 12px;
    border-radius: 5px;
    display: inline-block;
}

.season-period { 
    color: var(--texto-gris); 
    margin: 10px 0;
    font-style: italic;
    font-size: 1em;
}

/* Grid de estaciones */
.seasons-info { margin: 50px 0; }
.seasons-info h4 {
    text-align: center;
    color: var(--texto-oscuro);
    margin-bottom: 25px;
    font-size: 1.5em;
}

.seasons-grid { 
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
    gap: 25px; 
    margin-top: 20px; 
}

.season-info-card { 
    padding: 0;
    border-radius: 10px; 
    transition: all 0.3s ease; 
    border: 3px solid transparent;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    min-height: 140px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.season-mini-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.95);
    padding: 15px;
    border-top: 4px solid;
}

.season-info-card.verano { border-color: #E53E3E; }
.season-info-card.verano .season-mini-overlay { border-top-color: #E53E3E; }

.season-info-card.otoño { border-color: #D69E2E; }
.season-info-card.otoño .season-mini-overlay { border-top-color: #D69E2E; }

.season-info-card.invierno { border-color: #6CB2EB; }
.season-info-card.invierno .season-mini-overlay { border-top-color: #6CB2EB; }

.season-info-card.primavera { border-color: #68D391; }
.season-info-card.primavera .season-mini-overlay { border-top-color: #68D391; }

.season-info-card.current { 
    transform: scale(1.05); 
    box-shadow: 0 8px 25px rgba(139, 95, 191, 0.4); 
}

.season-info-card h5 { 
    color: var(--texto-oscuro); 
    margin-bottom: 8px;
    font-size: 1.2em;
}

.season-dates { 
    color: var(--texto-oscuro); 
    font-size: 0.85em; 
    line-height: 1.4; 
    margin: 0;
    font-weight: bold;
}

small { color: var(--texto-gris); font-size: 0.8em; margin-top: 5px; display: block; }

/* Estilos de fallback para cuando no hay imágenes */
.season-card.verano { background-color: #FED7D7; }
.season-card.otoño { background-color: #FEEBC8; }
.season-card.invierno { background-color: #BEE3F8; }
.season-card.primavera { background-color: #C6F6D5; }
.season-info-card.verano { background-color: #FED7D7; }
.season-info-card.otoño { background-color: #FEEBC8; }
.season-info-card.invierno { background-color: #BEE3F8; }
.season-info-card.primavera { background-color: #C6F6D5; }
</style>

<?php include_once '../footer.php'; ?>