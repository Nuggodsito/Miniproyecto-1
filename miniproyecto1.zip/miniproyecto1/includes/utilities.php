<?php
/**
 * Clase Utilities - Métodos estáticos para validación y utilidades
 * Cumple con PSR-1: StudlyCaps para clases, camelCase para métodos
 */
class Utilities
{
    /**
     * Validar si un valor está en una lista permitida
     * @param mixed $valor
     * @param array $listaPermitida
     * @return bool
     */
    public static function validarEnLista($valor, $listaPermitida)
    {
        return in_array($valor, $listaPermitida);
    }

    /**
     * Función NVL - Retorna valor por defecto si variable no está definida
     * @param mixed $var
     * @param mixed $default
     * @return mixed
     */
    public static function nvl(&$var, $default = "")
    {
        return isset($var) ? $var : $default;
    }

    /**
     * Validar número entero positivo
     * @param string $numero
     * @return bool
     */
    public static function validarEnteroPositivo($numero)
    {
        return preg_match('/^[1-9][0-9]*$/', $numero) && filter_var($numero, FILTER_VALIDATE_INT);
    }

    /**
     * Validar número decimal positivo
     * @param string $numero
     * @return bool
     */
    public static function validarDecimalPositivo($numero)
    {
        return preg_match('/^[0-9]+(\.[0-9]+)?$/', $numero) && filter_var($numero, FILTER_VALIDATE_FLOAT);
    }

    /**
     * Validar fecha en formato mm/dd/yyyy
     * @param string $fecha
     * @return bool
     */
    public static function validarFecha($fecha)
    {
        return preg_match('/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/([0-9]{4})$/', $fecha);
    }

    /**
     * Sanitizar entrada de texto
     * @param string $texto
     * @return string
     */
    public static function sanitizarTexto($texto)
    {
        return htmlspecialchars(trim($texto), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitizar número
     * @param string $numero
     * @return float
     */
    public static function sanitizarNumero($numero)
    {
        return filter_var($numero, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    }

    /**
     * Validar email
     * @param string $email
     * @return bool
     */
    public static function validarEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Generar enlace de navegación
     * @param string $url
     * @param string $texto
     * @return string
     */
    public static function generarEnlace($url, $texto = "Volver al Menú")
    {
        return '<a href="' . htmlspecialchars($url) . '" class="nav-link">' . htmlspecialchars($texto) . '</a>';
    }

    /**
     * Calcular desviación estándar
     * @param array $numeros
     * @return float
     */
    public static function calcularDesviacionEstandar($numeros)
    {
        $n = count($numeros);
        if ($n <= 1) return 0;

        $media = array_sum($numeros) / $n;
        $sumaCuadrados = 0;

        foreach ($numeros as $numero) {
            $sumaCuadrados += pow($numero - $media, 2);
        }

        return sqrt($sumaCuadrados / ($n - 1));
    }
}
?>